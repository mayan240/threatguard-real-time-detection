package com.threatguard.api;

import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import weka.clusterers.SimpleKMeans;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

@Service
public class WekaAnomalyService {
  private static final int FEATURE_COUNT = 5;
  private SimpleKMeans model;
  private Instances schema;
  private Instances centroids;
  private double threshold;
  private ModelMetrics metrics;

  @PostConstruct
  void train() throws Exception {
    List<Sample> samples = loadSamples();
    schema = new Instances("security-events", attributes(), 0);
    Instances normalBaseline = new Instances(schema, 0);
    for (Sample sample : samples) if (sample.label.equals("NORMAL")) normalBaseline.add(instance(sample.features));

    model = new SimpleKMeans();
    model.setSeed(42);
    model.setNumClusters(Math.min(3, normalBaseline.numInstances()));
    model.setPreserveInstancesOrder(true);
    model.buildClusterer(normalBaseline);
    centroids = model.getClusterCentroids();

    List<Double> baselineDistances = new ArrayList<>();
    for (Instance item : normalBaseline) baselineDistances.add(nearestDistance(item));
    double mean = baselineDistances.stream().mapToDouble(Double::doubleValue).average().orElse(0.1);
    double variance = baselineDistances.stream().mapToDouble(value -> Math.pow(value - mean, 2)).average().orElse(0);
    threshold = Math.max(0.15, mean + 2 * Math.sqrt(variance));
    metrics = evaluate(samples, normalBaseline.numInstances());
  }

  public double score(SecurityEvent event) {
    if (model == null) return 0;
    return Math.min(60, Math.round((nearestDistance(instance(features(event))) / threshold) * 60));
  }

  public String explanation(SecurityEvent event) {
    double distance = nearestDistance(instance(features(event)));
    return String.format("Weka K-Means distance %.3f (threshold %.3f)", distance, threshold);
  }

  public ModelMetrics metrics() { return metrics; }

  private ModelMetrics evaluate(List<Sample> samples, int baselineCount) {
    int truePositive = 0, falsePositive = 0, falseNegative = 0;
    for (Sample sample : samples) {
      boolean predicted = nearestDistance(instance(sample.features)) > threshold;
      boolean actual = sample.label.equals("ANOMALY");
      if (predicted && actual) truePositive++;
      if (predicted && !actual) falsePositive++;
      if (!predicted && actual) falseNegative++;
    }
    double precision = truePositive + falsePositive == 0 ? 0 : (double) truePositive / (truePositive + falsePositive);
    double recall = truePositive + falseNegative == 0 ? 0 : (double) truePositive / (truePositive + falseNegative);
    double f1 = precision + recall == 0 ? 0 : 2 * precision * recall / (precision + recall);
    return new ModelMetrics("Weka SimpleKMeans (k=3)", baselineCount, samples.size(), round(threshold), round(precision), round(recall), round(f1));
  }

  private List<Sample> loadSamples() throws Exception {
    List<Sample> samples = new ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new InputStreamReader(new ClassPathResource("training-security-events.csv").getInputStream(), StandardCharsets.UTF_8))) {
      reader.readLine(); String line;
      while ((line = reader.readLine()) != null) {
        String[] values = line.split(",");
        samples.add(new Sample(new double[]{Double.parseDouble(values[0]), Double.parseDouble(values[1]), Double.parseDouble(values[2]), Double.parseDouble(values[3]) / 25.0, Double.parseDouble(values[4]) / 23.0}, values[5]));
      }
    }
    return samples;
  }

  private ArrayList<Attribute> attributes() {
    ArrayList<Attribute> attributes = new ArrayList<>();
    attributes.add(new Attribute("failed_login")); attributes.add(new Attribute("privileged_user")); attributes.add(new Attribute("suspicious_source")); attributes.add(new Attribute("data_volume")); attributes.add(new Attribute("hour"));
    return attributes;
  }

  private double[] features(SecurityEvent event) {
    int hour = event.getObservedAt().atZone(ZoneId.systemDefault()).getHour();
    return new double[]{event.getEventType().contains("FAILED") ? 1 : 0, isPrivileged(event.getUsername()) ? 1 : 0, suspiciousIp(event.getSourceIp()) ? 1 : 0, Math.min(1, event.getBytesTransferred() / 25_000_000.0), hour / 23.0};
  }
  private boolean isPrivileged(String username) { return username.equalsIgnoreCase("root") || username.equalsIgnoreCase("admin"); }
  private boolean suspiciousIp(String sourceIp) { return sourceIp.startsWith("185.") || sourceIp.startsWith("45."); }
  private Instance instance(double[] values) { DenseInstance instance = new DenseInstance(1, values); instance.setDataset(schema); return instance; }
  private double nearestDistance(Instance item) { double nearest = Double.MAX_VALUE; for (Instance centroid : centroids) { double sum = 0; for (int i = 0; i < FEATURE_COUNT; i++) sum += Math.pow(item.value(i) - centroid.value(i), 2); nearest = Math.min(nearest, Math.sqrt(sum)); } return nearest; }
  private double round(double value) { return Math.round(value * 1000.0) / 1000.0; }
  private record Sample(double[] features, String label) {}
}
