package com.threatguard.api;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:8000", "http://127.0.0.1:8000"})
public class ThreatController {
  private final EventRepository events; private final EventService eventService; private final WekaAnomalyService weka; private final WebsiteHealthService websiteHealth;
  ThreatController(EventRepository events, EventService eventService, WekaAnomalyService weka, WebsiteHealthService websiteHealth){this.events=events;this.eventService=eventService;this.weka=weka;this.websiteHealth=websiteHealth;}
  @GetMapping("/events") public List<SecurityEvent> recent(){ return events.findTop50ByOrderByObservedAtDesc(); }
  @GetMapping("/alerts") public List<SecurityEvent> alerts(){ return recent().stream().filter(e -> e.getAnomalyScore() >= 50).toList(); }
  @GetMapping("/metrics") public Map<String,Object> metrics(){
    List<SecurityEvent> all=events.findAll(); double average=all.stream().mapToDouble(SecurityEvent::getAnomalyScore).average().orElse(0);
    return Map.of("events",all.size(),"critical",events.countBySeverityIn(List.of("CRITICAL")),"high",events.countBySeverityIn(List.of("HIGH")),"openAlerts",events.countByAlertStatus("OPEN"),"averageRisk",Math.round(average*10)/10.0);
  }
  @GetMapping("/ml/metrics") public ModelMetrics modelMetrics(){ return weka.metrics(); }
  @PostMapping("/website/check") public WebsiteHealthService.WebsiteHealth checkWebsite(@Valid @RequestBody WebsiteCheckRequest request){
    return websiteHealth.check(request.url());
  }
  @PostMapping("/events") @ResponseStatus(HttpStatus.CREATED) public SecurityEvent ingest(@Valid @RequestBody IngestRequest request, @RequestHeader(value="X-API-Key", required=false) String apiKey){
    String requiredKey=System.getenv().getOrDefault("THREATGUARD_INGEST_KEY","demo-ingest-key");
    if (!requiredKey.equals(apiKey)) throw new org.springframework.web.server.ResponseStatusException(HttpStatus.UNAUTHORIZED,"Valid X-API-Key required");
    return eventService.ingest(request.sourceIp(),request.username(),request.eventType(),request.bytesTransferred(),request.customerId()==null?"demo-workspace":request.customerId(),request.assetName()==null?"unassigned":request.assetName());
  }
  @PatchMapping("/alerts/{id}") public SecurityEvent triage(@PathVariable Long id,@RequestBody TriageRequest request){
    SecurityEvent event=events.findById(id).orElseThrow(()->new org.springframework.web.server.ResponseStatusException(HttpStatus.NOT_FOUND));
    if (!List.of("OPEN","TRIAGED","RESOLVED").contains(request.status())) throw new org.springframework.web.server.ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid status");
    event.triage(request.status()); return events.save(event);
  }
  public record IngestRequest(@NotBlank String sourceIp,@NotBlank String username,@NotBlank String eventType,@PositiveOrZero long bytesTransferred,String customerId,String assetName){}
  public record TriageRequest(@NotBlank String status){}
  public record WebsiteCheckRequest(@NotBlank String url){}
}
